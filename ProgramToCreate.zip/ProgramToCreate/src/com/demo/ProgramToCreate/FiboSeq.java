package com.demo.ProgramToCreate;

	import java.util.Scanner;

	public class FiboSeq {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Enter the nos of terms in the Fibo seq: ");
	        int n = scanner.nextInt();
	        
	        if (n <= 0) {
	            System.out.println("Enter positive value");
	        } else {
	            createPrintFibo(n);
	        }
	        
	        scanner.close();
	    }
	    
	    public static void createPrintFibo(int n) {
	        int a = 0;
	        int b = 1;
	        
	        System.out.println("Fibo Seq (first " + n + " terms):");
	        for (int i = 1; i <= n; i++) {
	            System.out.print(a + " ");
	            
	            int sum = a + b;
	            a = b;
	            b = sum;
	        }
	    }
	}


